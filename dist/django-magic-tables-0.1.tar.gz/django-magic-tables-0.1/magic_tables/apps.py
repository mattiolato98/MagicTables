from django.apps import AppConfig


class MagicTablesConfig(AppConfig):
    name = 'magic_tables'
